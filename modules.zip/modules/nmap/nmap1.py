import os

x = input("enter the ip:  ")

x1 = "nmap " + x
os.system(x1)
