import argparse
import getpass
import json
import os
import requests

def LoginRequest(request):
    global session
    session = requests.Session()
    session.headers.update({'Referer': 'https://www.instagram.com/'})
    req = session.get('https://www.instagram.com/')
    session.headers.update({'X-CSRFToken': req.cookies['csrftoken']})
    login_response = session.post('https://www.instagram.com/accounts/login/ajax/', data=request, allow_redirects=True).json()
    if 'two_factor_required' in login_response and login_response['two_factor_required']:
        identifier = login_response['two_factor_info']['two_factor_identifier']
        username = credential['username']
        verification_code = input('Enter your Two-Step-Verification-Code: ')
        verification_data = {'username': username, 'verificationCode': verification_code, 'identifier': 
identifier}
        two_factor_response = session.post('https://www.instagram.com/accounts/login/ajax/two_factor/', 
data=verification_data, allow_redirects=True).json()
        if two_factor_response['authenticated']:
            return session, two_factor_response
        else:
            return None, two_factor_response
    return session, login_response
    
def login():
    user, pwd = "", ""
    while True:
        username = input("Enter your username:  ")
        password = getpass.getpass(prompt='Password: ')
        session, res = LoginRequest({"username": username, "password": password})
        if res['authenticated']:
            download()
            break
        if not res['authenticated']:
            print("The username or password is incorrect")
        if res['status'] == 'fail':
            print(res['message'])
            exit() 
    return session
def main():
    parser = argparse.ArgumentParser()
    session = login()

def download():
    global session
    url = input("Enter the link:  ")
    r = requests.get(url, cookies=session.cookies, allow_redirects=True)
    open("following.json","wb").write(r.content)
    export()
def export():
  input1 = input("Enter 1 to continue: ")
  if input1=="1":
    pass
  else:
    exit()
  with open("followers.txt", 'w') as followers:
    with open('following.json') as data:
      data1 = json.load(data)
      placement = data1["data"]["user"]["feed_reels_tray"]["edge_reels_tray_to_reel"]["edges"]
      length = len(placement)
      for reg in range(length):
        followers.write(placement[reg]["node"]["user"]["username"] + os.linesep)
        print(placement[reg]["node"]["user"]["username"])
if __name__ == '__main__':
    main()

