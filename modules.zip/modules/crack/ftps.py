import os

x = input("enter the target ip: ")
y = input("enter the target user: ")
z = input("enter the wordlist: ")

h = "python2 modules/crack/ftp.py " + x + " " + y + " " + z
os.system(h)
