import os
os.system("clear")


print'''

==    %% ==     ==  == ==   ==  $$$$$ $$$$$$
==    == ====== ==  ==  == ==   $   $ $$
==    == ==  == ==  ==   ===    $   $ $$$$$$
===== == ==  == ======  == ==   $   $     $$
===== == ==  ==     == ==   ==  $$$$$ $$$$$$

    https://jailbreakandroot.tk
    code by mehdi652 & mohamadg80
'''
print'''

  {1} kali
  ========================
  {2} ubuntu
  ========================
  {3} debian
  ========================
  {4} fedora
  ========================
  {5} arch
  ========================
  {6} black arch
  ========================
  {7} parrot security OS
  ========================
  {99} back
'''

x = input("jailbreakandroot=>  ")

if x == 1:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Kali/kali.sh && bash kali.sh")
if x == 2:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Ubuntu/ubuntu.sh && bash ubuntu.sh")
if x == 3:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Debian/debian.sh && bash debian.sh")
if x == 4:
   os.system("cd $HOME")
   os.system("pkg install wget proot tar -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Fedora/fedora.sh && bash fedora.sh")
if x == 5:
   os.system("cd $HOME")
   os.system("pkg install wget proot tar -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Arch/armhf/arch.sh && bash arch.sh")
if x == 6:
   os.system("cd $HOME")
   os.system("pacman-key --init && pacman-key --populate archlinuxarm && pacman -Sy --noconfirm curl && curl -O https://blackarch.org/strap.sh && chmod +x strap.sh && ./strap.sh")
if x == 7:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Parrot/parrot.sh && bash parrot.sh")
if x == 99:
   os.system("python2 jrf.py")
